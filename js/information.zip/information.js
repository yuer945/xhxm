$(function(){
	var imgUl = $(".imgUl");
	var onOff = true;
	
	$(".next").on("click",function(){
		
		imgUl.find(".li2").animate({
			"top":0,
			"left":"205px",
			"width":"720px",
			"height":"512px"
		},500);
		
		$(".li3").animate({
			"top":"150px",
			"left":"105px"
		},500);
		
		$(".li4").animate({
			"top":"200px",
			"left":"85px"
		},500);
		
		$(".li5").animate({
			"top":"250px",
			"left":"65px"
		},500);
		
		$(".li1").fadeOut(500).css("display","block");
		imgUl.find(".li1").appendTo(imgUl);
		$.each(imgUl.find("li"), function(index) {
			$(this).removeClass();
			$(this).addClass("li"+(index+1));
			$(this).show();
		});
		$(".li5").css({"width": "289px", "height": "180px","top":"300px","left":"45px","display":"block"});
		$(".li5").show();
	});
	
	$.each(imgUl.find("li"), function() {
		imgUl.find("li").css("display","block");
	});
});
